#include <map>
#include <string>

std::map<std::string, std::string>m;
std::map<std::string, std::string>::iterator iter;

extern "C" int open() {
	
	return 0;
}

